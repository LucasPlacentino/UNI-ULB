# LCD-I2C-Raspberry-Pi-2
Library for LCD I2C Backpack Supports 16x2 and 20x4 screens. Raspberry Pi 2

<b>Hardware:</b>

LCD 16x2

LCD1602 serial monitor ( PCF )

	http://g03.a.alicdn.com/kf/HTB1rgngKFXXXXbXXFXXq6xXFXXXU/1Pcs-IIC-I2C-Serial-Interface-Board-Module-LCD1602-LCD2004-Display-for-Arduino-Hot-Worldwide.jpg_640x640.jpg

Raspberry Pi 2
	
How to use:
	
	https://youtu.be/i5A5AsDRRwQ

Run
	
	sudo python lcd.py