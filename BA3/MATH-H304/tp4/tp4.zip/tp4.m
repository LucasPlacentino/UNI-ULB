% TP 4 automatique

% tf, rlocus, rolcfind





